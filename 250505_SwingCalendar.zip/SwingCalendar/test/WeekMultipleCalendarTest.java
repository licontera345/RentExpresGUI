
import com.pinguela.SwingMultipleCalendar.EventOverlapException;
import com.pinguela.SwingMultipleCalendar.MultipleCalendar;
import com.pinguela.SwingMultipleCalendar.MultipleCalendarEvent;
import com.pinguela.SwingMultipleCalendar.WeekMultipleCalendar;
import com.pinguela.SwingMultipleCalendar.dialog.MultipleCalendarEventDialog;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public class WeekMultipleCalendarTest {
    public static void main(String[] args) {
        JFrame frm = new JFrame();

        ArrayList<MultipleCalendarEvent> events = new ArrayList<>();

        events.add(new MultipleCalendarEvent(LocalDate.now(), LocalTime.of(14, 30), LocalTime.of(14,45 ), "Test 8/3 14:30-14:45", 0));

        WeekMultipleCalendar cal = new WeekMultipleCalendar(events);

        cal.addCalendarEventClickListener(e -> {  	
        	System.out.println("WeekMultipleCalendarTest: "+ e.getMultipleCalendarEvent());
        	MultipleCalendarEventDialog calendarEventDialog = new MultipleCalendarEventDialog(e.getMultipleCalendarEvent(), cal);
        	calendarEventDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        	calendarEventDialog.setDialogLabel("Edit Event");
        	calendarEventDialog.setModal(true);     	
        	calendarEventDialog.setRemoveActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent ev) {
					//System.out.println("WeekMultipleCalendarTest: remove: "+ e.getCalendarEvent());
					cal.removeEvent(e.getMultipleCalendarEvent());			
					calendarEventDialog.dispose();
				}
        	});
        	
        	calendarEventDialog.setOkActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent ev) {
					cal.removeEvent(e.getMultipleCalendarEvent());
					try {
						cal.addEvent(calendarEventDialog.getMultipleCalendarEvent());
						calendarEventDialog.dispose();
					} catch (EventOverlapException e1) {
						calendarEventDialog.setDialogErrorLabel(e1.getMessage());
					}
					
				}
        	});     
        	calendarEventDialog.setVisible(true); 
        });
        
        
        cal.addCalendarEmptyClickListener(e -> {
            LocalTime timeRounded = MultipleCalendar.roundTime(e.getDateTime().toLocalTime(), 30);
            MultipleCalendarEvent newCalendarEvent = new MultipleCalendarEvent(e.getDateTime().toLocalDate(),
					timeRounded, 
					timeRounded.plusMinutes(15), "Write event details...", 0);
            
            MultipleCalendarEventDialog newCalendarEventDialog = new MultipleCalendarEventDialog(newCalendarEvent, cal);
            newCalendarEventDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            newCalendarEventDialog.hideRemoveButton();
        	newCalendarEventDialog.setModal(true);
            newCalendarEventDialog.setDialogLabel("New Event");

            newCalendarEventDialog.setOkActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent ev) {
					System.out.println("WeekMultipleCalendarTest: " +newCalendarEventDialog.getMultipleCalendarEvent());
					try {
						cal.addEvent(newCalendarEventDialog.getMultipleCalendarEvent());
						newCalendarEventDialog.dispose();
					} catch (EventOverlapException e1) {
						newCalendarEventDialog.setDialogErrorLabel(e1.getMessage());
					}
				
					cal.repaint();
					
				}
            	
            });   
            newCalendarEventDialog.setVisible(true);         
        });

        JButton goToTodayBtn = new JButton("Today");
        goToTodayBtn.addActionListener(e -> cal.goToToday());

        JButton nextWeekBtn = new JButton(">");
        nextWeekBtn.addActionListener(e -> cal.nextWeek());

        JButton prevWeekBtn = new JButton("<");
        prevWeekBtn.addActionListener(e -> cal.prevWeek());

        JButton nextMonthBtn = new JButton(">>");
        nextMonthBtn.addActionListener(e -> cal.nextMonth());

        JButton prevMonthBtn = new JButton("<<");
        prevMonthBtn.addActionListener(e -> cal.prevMonth());

        JPanel weekControls = new JPanel();
        weekControls.add(prevMonthBtn);
        weekControls.add(prevWeekBtn);
        weekControls.add(goToTodayBtn);
        weekControls.add(nextWeekBtn);
        weekControls.add(nextMonthBtn);

        frm.add(weekControls, BorderLayout.NORTH);

        frm.add(cal, BorderLayout.CENTER);
        frm.setSize(800, 900 );
        frm.setMinimumSize(new Dimension(700,700));
        frm.setVisible(true);
        frm.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}

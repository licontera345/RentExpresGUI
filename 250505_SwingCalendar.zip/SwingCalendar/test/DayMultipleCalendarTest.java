
import javax.swing.*;

import com.pinguela.SwingMultipleCalendar.DayMultipleCalendar;
import com.pinguela.SwingMultipleCalendar.EventOverlapException;
import com.pinguela.SwingMultipleCalendar.MultipleCalendar;
import com.pinguela.SwingMultipleCalendar.MultipleCalendarEvent;
import com.pinguela.SwingMultipleCalendar.dialog.MultipleCalendarEventDialog;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public class DayMultipleCalendarTest {
    public static void main(String[] args) {
        JFrame frm = new JFrame();

        ArrayList<MultipleCalendarEvent> events = new ArrayList<>();

        events.add(new MultipleCalendarEvent(LocalDate.now(), LocalTime.of(11, 30), LocalTime.of(11,45 ), "Test 9/3 11:30-11:45", 0));

        DayMultipleCalendar cal = new DayMultipleCalendar(events);
        

        cal.addCalendarEventClickListener(e -> {
        	System.out.println("DayMultipleCalendarTets: "+e.getMultipleCalendarEvent());
        	MultipleCalendarEventDialog calendarEventDialog = new MultipleCalendarEventDialog(e.getMultipleCalendarEvent(), cal);
        	calendarEventDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        	calendarEventDialog.setDialogLabel("Edit Event");
        	calendarEventDialog.setModal(true);
        	calendarEventDialog.setRemoveActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent ev) {
					//System.out.println("DayMultipleCalendarTest: remove: "+ e.getCalendarEvent());
					cal.removeEvent(e.getMultipleCalendarEvent());			
					calendarEventDialog.dispose();
				}
        	});
        	calendarEventDialog.setOkActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent ev) {
					cal.removeEvent(e.getMultipleCalendarEvent());
					try {
						cal.addEvent(calendarEventDialog.getMultipleCalendarEvent());
						calendarEventDialog.dispose();
					} catch (EventOverlapException e1) {
						calendarEventDialog.setDialogErrorLabel(e1.getMessage());
					}
					
				}
        	});    
        	calendarEventDialog.setVisible(true); 
        	
        });
        cal.addCalendarEmptyClickListener(e -> {
            //System.out.println(e.getDateTime());
            //System.out.println(MultipleCalendar.roundTime(e.getDateTime().toLocalTime(), 30));
        	  LocalTime timeRounded = MultipleCalendar.roundTime(e.getDateTime().toLocalTime(), 30);
              MultipleCalendarEvent newCalendarEvent = new MultipleCalendarEvent(e.getDateTime().toLocalDate(),
  					timeRounded, 
  					timeRounded.plusMinutes(15), "Write event details...", 0);   
              MultipleCalendarEventDialog newCalendarEventDialog = new MultipleCalendarEventDialog(newCalendarEvent, cal);
              newCalendarEventDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
              newCalendarEventDialog.hideRemoveButton();
              newCalendarEventDialog.setDialogLabel("New Event");
              newCalendarEventDialog.setModal(true);
              newCalendarEventDialog.setOkActionListener(new ActionListener() {
  				@Override
  				public void actionPerformed(ActionEvent ev) {
  					System.out.println("DayMultipleCalendarTest: " +newCalendarEventDialog.getMultipleCalendarEvent());
  					try {
  						cal.addEvent(newCalendarEventDialog.getMultipleCalendarEvent());
  						newCalendarEventDialog.dispose();
  					} catch (EventOverlapException e1) {
  						newCalendarEventDialog.setDialogErrorLabel(e1.getMessage());
  					}			
  					cal.repaint();
  				}
              });
              newCalendarEventDialog.setVisible(true);
        });
        JButton goToTodayBtn = new JButton("Today");
        goToTodayBtn.addActionListener(e -> cal.goToToday());

        JButton nextDayBtn = new JButton(">");
        nextDayBtn.addActionListener(e -> cal.nextDay());

        JButton prevDayBtn = new JButton("<");
        prevDayBtn.addActionListener(e -> cal.prevDay());

        JPanel weekControls = new JPanel();
        weekControls.add(prevDayBtn);
        weekControls.add(goToTodayBtn);
        weekControls.add(nextDayBtn);

        frm.add(weekControls, BorderLayout.NORTH);

        frm.add(cal, BorderLayout.CENTER);
        frm.setSize(1000, 900);
        frm.setVisible(true);
        frm.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}

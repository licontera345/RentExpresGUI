import com.davidmoodie.SwingCalendar.Calendar;
import com.davidmoodie.SwingCalendar.CalendarEvent;
import com.davidmoodie.SwingCalendar.WeekCalendar;
import com.davidmoodie.SwingCalendar.dialog.CalendarEventDialog;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public class WeekCalendarTest {
    public static void main(String[] args) {
        JFrame frm = new JFrame();

        ArrayList<CalendarEvent> events = new ArrayList<>();
//        events.add(new CalendarEvent(LocalDate.of(2016, 11, 11), LocalTime.of(14, 0), LocalTime.of(14, 20), "Test 11/11 14:00-14:20"));
//        events.add(new CalendarEvent(LocalDate.of(2016, 11, 14), LocalTime.of(9, 0), LocalTime.of(9, 20), "Test 14/11 9:00-9:20"));
//        events.add(new CalendarEvent(LocalDate.of(2016, 11, 15), LocalTime.of(12, 0), LocalTime.of(13, 20), "Test 15/11 12:00-13:20"));
//        events.add(new CalendarEvent(LocalDate.of(2016, 11, 16), LocalTime.of(9, 0), LocalTime.of(9, 20), "Test 16/11 9:00-9:20"));
//        events.add(new CalendarEvent(LocalDate.of(2016, 11, 17), LocalTime.of(12, 15), LocalTime.of(14, 20), "Test 17/11 12:15-14:20"));
//        events.add(new CalendarEvent(LocalDate.of(2016, 11, 18), LocalTime.of(9, 30), LocalTime.of(10, 00), "Test 18/11 9:30-10:00"));
//        events.add(new CalendarEvent(LocalDate.of(2016, 11, 18), LocalTime.of(16, 00), LocalTime.of(16, 45), "Test 18/11 16:00-16:45"));
        events.add(new CalendarEvent(LocalDate.of(2025, 3, 28), LocalTime.of(14, 30), LocalTime.of(14,45 ), "Test 8/3 14:30-14:45", Color.LIGHT_GRAY));

        WeekCalendar cal = new WeekCalendar(events);

        cal.addCalendarEventClickListener(e -> {  	
        	System.out.println(e.getCalendarEvent());
        	CalendarEventDialog calendarEventDialog = new CalendarEventDialog(e.getCalendarEvent());
        	calendarEventDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        	calendarEventDialog.setDialogTypeLabel("Edit Event");
        	calendarEventDialog.setVisible(true);      	
        	calendarEventDialog.setRemoveActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent ev) {
					//System.out.println("remove: "+ e.getCalendarEvent());
					cal.removeEvent(e.getCalendarEvent());			
					calendarEventDialog.dispose();
				}
        	});
        	
        	calendarEventDialog.setOkActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent ev) {
					cal.removeEvent(e.getCalendarEvent());
					cal.addEvent(calendarEventDialog.getCalendarEvent());
					calendarEventDialog.dispose();
				}
        	});        
        });
        
        
        cal.addCalendarEmptyClickListener(e -> {
            LocalTime timeRounded =  Calendar.roundTime(e.getDateTime().toLocalTime(), 30);
            CalendarEvent newCalendarEvent = new CalendarEvent(e.getDateTime().toLocalDate(),
					timeRounded, 
					timeRounded.plusMinutes(15), "Write event details...");
            
            CalendarEventDialog newCalendarEventDialog = new CalendarEventDialog(newCalendarEvent);
            newCalendarEventDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            newCalendarEventDialog.hideRemoveButton();
            newCalendarEventDialog.setDialogTypeLabel("New Event");
            newCalendarEventDialog.setVisible(true);
            newCalendarEventDialog.setOkActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent ev) {
					cal.addEvent(newCalendarEventDialog.getCalendarEvent());
					cal.repaint();
					newCalendarEventDialog.dispose();
				}
            	
            });       
            
        });

        JButton goToTodayBtn = new JButton("Today");
        goToTodayBtn.addActionListener(e -> cal.goToToday());

        JButton nextWeekBtn = new JButton(">");
        nextWeekBtn.addActionListener(e -> cal.nextWeek());

        JButton prevWeekBtn = new JButton("<");
        prevWeekBtn.addActionListener(e -> cal.prevWeek());

        JButton nextMonthBtn = new JButton(">>");
        nextMonthBtn.addActionListener(e -> cal.nextMonth());

        JButton prevMonthBtn = new JButton("<<");
        prevMonthBtn.addActionListener(e -> cal.prevMonth());

        JPanel weekControls = new JPanel();
        weekControls.add(prevMonthBtn);
        weekControls.add(prevWeekBtn);
        weekControls.add(goToTodayBtn);
        weekControls.add(nextWeekBtn);
        weekControls.add(nextMonthBtn);

        frm.add(weekControls, BorderLayout.NORTH);

        frm.add(cal, BorderLayout.CENTER);
        frm.setSize(800, 900 );
        frm.setMinimumSize(new Dimension(700,700));
        frm.setVisible(true);
        frm.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}

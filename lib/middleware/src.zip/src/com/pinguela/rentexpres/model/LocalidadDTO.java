package com.pinguela.rentexpres.model;

public class LocalidadDTO extends ValueObject {

    private Integer id;
    private String nombre;      
    private Integer idProvincia; 

    public LocalidadDTO() {
        super();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Integer getIdProvincia() {
        return idProvincia;
    }

    public void setIdProvincia(Integer idProvincia) {
        this.idProvincia = idProvincia;
    }
}
